package gitlet;

import java.io.*;
import java.util.*;

/**
 * Represents a Git directory
 */
public class Gitlet {

    private static class Commit {

        public final String parentSha;
        public final Date timeStamp;
        public final String comment;
        public final List<FileVersion> files = new ArrayList<>();

        public Commit(String parentSha, Date timeStamp, String comment, Collection<FileVersion> files) {
            this.parentSha = parentSha;
            this.timeStamp = timeStamp;
            this.comment = comment;
            this.files.addAll(files);
        }

        public String sha() {
            Object[] data = new Object[3 + files.size()];
            int i = 0;
            data[i++] = parentSha;
            data[i++] = timeStamp.toString();
            data[i++] = comment;
            for (FileVersion file : files) {
                data[i++] = file.toString();
            }
            return Utils.sha1(data);
        }

        private static class FileVersion implements Serializable {
            private final String canonicalName;
            private final String contents;

            public FileVersion(String canonicalName, String contents) {
                this.canonicalName = canonicalName;
                this.contents = contents;
            }

            @Override
            public String toString() {
                return "FileVersion{" +
                        "canonicalName='" + canonicalName + '\'' +
                        ", contents='" + contents + '\'' +
                        '}';
            }
        }
    }

    public final Map<String, String> namedCommits = new HashMap<>();
    public final Map<String, Commit> allCommits = new HashMap<>();

    /** True iff this gitlet is a new instance (needs init) */
    private boolean isNew;
    /** The .gitlet directory. */
    private final File dotGitlet;

    public Gitlet(File directory) {
        if (directory.isFile() || !directory.exists()) {
            throw new IllegalStateException("cannot init inside file or not exists");
        }
        dotGitlet = new File(directory, ".gitlet");
        if (dotGitlet.isFile()) {
            throw new IllegalStateException(".gitlet is file");
        }
        this.isNew = dotGitlet.exists();
    }

    private void readCommits() {
        Map<String, String> commits;

        File commitsDotGitlet = new File(dotGitlet, "commits.gitlet");
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(commitsDotGitlet))) {

            commits = (Map<String, String>) in.readObject();

        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        for (Map.Entry<String, String> e : commits.entrySet()) {
            if (e.getKey().equals(e.getValue())) {
                allCommits.put(e.getKey(), null);
            }
            else {
                namedCommits.put(e.getKey(), e.getValue());
            }
        }
    }

    public String init() {
        if (!isNew) {
            return "A gitlet version-control system already exists in the current directory.";
        }
        dotGitlet.mkdir();

        Commit initial = new Commit(null, new Date(), "initial commit", Collections.emptySet());
        String sha = initial.sha();

        namedCommits.put("master", sha);
        allCommits.put(sha, initial);

        return null;
    }

    private void writeCommits() {

        Map<String, String> commits = new HashMap<>();
        commits.putAll(namedCommits);
        allCommits.forEach((s, c) -> commits.put(s, s));

        File commitsDotGitlet = new File(dotGitlet, "commits.gitlet");
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(commitsDotGitlet))) {

            out.writeObject(commits);
            out.flush();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void writeData() {

    }
}
